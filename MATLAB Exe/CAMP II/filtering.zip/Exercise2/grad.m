function [dxu dyu] = grad(u)
% [dxu dyu] = grad(u) computes the gradient of the function u
% with forward differences assuming
% Neumann boundary conditions
%
% written by
% Maximilian Baust
% April 20th 2009
% Chair for Computer Aided Medical Procedures & Augmented Reality
% Technische Universit�t M�nchen

[m n] = size(u);

dxu = zeros(m,n);
dyu = zeros(m,n);

%approximate the derivative of u in x-direction with forward differences
dxu(:,1:end-1) = u(:,2:end)-u(:,1:end-1);

%approximate the derivative of u in y-direction with forward differences
dyu(1:end-1,:) = u(2:end,:)-u(1:end-1,:);


