function Y = imfft(X)

%% The function returns the 2D fourier transform of the input image X
%% Hint: use the functions fft2, fftshift

Y = fftshift(fft2(X));
 